<?php 
function mrt_sms_support_page(){ ?>

   <div class=wrap>
      <h2><?php _e('Wordpress Text Message Support') ?></h2>
      
      <div style="height:299px">
      <!--   <ul>
            <li><a href='' target="_blank">Changelog</a></li>
            <li><a href='' target="_blank">Documentation</a></li>
         </ul>-->
         <em>For comments, suggestions, bug reporting, etc please <a href="http://www.totalbounty.com/forums/topic/wordpress-text-message/">use our forum page for WordPress text Message here</a>.</em>
   <div>
     Wordpress Text Message Plugin enhanced by <a href="http://www.jtpratt.com/" title="JTPratt Media">JTPratt Media</a>, now sponsored by <a href="http://www.totalbounty.com">Total Bounty Marketplace</a><br />
     Visit the <a href="http://www.totalbounty.com/freebies/wordpress-text-message/">Wordpress Text Message Plugin Page</a><br />
      Based on the Original SMS Text Message Plugin by <a href="http://semperfiwebdesign.com/" title="Semper Fi Web Design">Semper Fi Web Design</a>
   </div>
<?php } ?>
