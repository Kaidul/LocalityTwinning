<?php
    function mrt_sms_add_subscribe() {
?>
    <h1> Add Subscribers </h1>

<p>You can manually add subscribers to your SMS text list<br />
here one by one.  This feature would be used if you were<br />
collecting cell phone numbers as part of an opt-in giveaway<br />
or contest where people won't be physically visiting your<br />
website - or other methods of obtaining opt-in leads who<br />
want updates from your site but didn't enter the number<br />
themselves using the front end widget.</p>

<?php
    mrt_sms_guts_widget();
    }
?>
